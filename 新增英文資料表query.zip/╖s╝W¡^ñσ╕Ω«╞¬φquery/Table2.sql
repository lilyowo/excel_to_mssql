CREATE TABLE MedSource(
	Source_id int NOT NULL,
	Source_name nvarchar(500),
	Source_link nvarchar(500),
	PRIMARY KEY(Source_id)
);